# Locating and Displaying Recognized Text on a Document

Overlay text recognition output from the document scanner onto an image, reporting progress throughout.

## Overview

- Note: For more information about this sample code project, see [WWDC 2019 Session 234: Text Recognition in Vision Framework](https://developer.apple.com/videos/play/wwdc19/234/).
